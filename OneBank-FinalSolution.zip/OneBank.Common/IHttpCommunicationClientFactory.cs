﻿namespace OneBank.Common
{
    using Microsoft.ServiceFabric.Services.Communication.Client;

    public interface IHttpCommunicationClientFactory : ICommunicationClientFactory<HttpCommunicationClient>
    {
    }
}